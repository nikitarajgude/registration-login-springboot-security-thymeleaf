package com.dss.springboot.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.dss.springboot.model.User;
import com.dss.springboot.webb.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService {
	User save(UserRegistrationDto registrationDto);
	

}
